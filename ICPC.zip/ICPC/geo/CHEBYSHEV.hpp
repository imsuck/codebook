pair<int, int> mantoche(int x, int y) {
    return {x + y, y - x};
}